﻿using System;

namespace Game
{
	class Program
	{
		public static void Main(string[] args)
		{
			Game g = new Game();
			g.CreateJeu();
			g.AfficherJeu();
			g.GetCarteAleatoire();
			g.GetCarteAleatoire();
			g.GetCarteAleatoire();
			Console.ReadKey(true);
		}
	}
}