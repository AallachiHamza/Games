﻿
using System;
using System.Collections.Generic;

namespace Game
{
	public class Game
	{
		string[] couleurs = {"carreau","trefle","coeur","pique"};
		string[] valeurs = {"1","2","3","4","5","6","7","8","9","10","V","D","R"};
		List<string> jeu = new List<string>();
		Random r = new Random();
		List<string> jeuOrdi = new List<string>();
		
		public void CreateJeu(){
			for(int i = 0; i < couleurs.Length;i++){
				string col = couleurs[i];
				for(int j = 0; j < valeurs.Length;j++){
					jeu.Add(valeurs[j]+"-"+col);
				}
			}
		}
		public void AfficherJeu(){
			for(int i = 0; i < jeu.Count;i++){
				Console.WriteLine(jeu[i]);
			}
		}
		public string GetCarteAleatoire(){
			int randomNumber = r.Next(jeu.Count);
			string carte = jeu[randomNumber];
			jeu.RemoveAt(randomNumber);
			return carte;
			//Console.WriteLine("Carte retirée: "+carte);
		}
		public void GetComputerCards(){
			while(GetValeurJeu() < 16){
				string carteTiree = GetCarteAleatoire();
				jeuOrdi.Add(carteTiree);
			}	
		}
		public int GetValeurJeu(){
			int result = 0;
			for(int i = 0; i < jeuOrdi.Count;i++){
				string carteTemp = jeuOrdi[i];
				string[] tableau = carteTemp.Split(new char[]{'-'});
				string valeurString = tableau[0];
				if(valeurString == "V" || valeurString == "D" || valeurString == "R"){
					result += 10;
				}else{
					result += Int32.Parse(valeurString);
				}
			}
			return result;
		}
	}
}
